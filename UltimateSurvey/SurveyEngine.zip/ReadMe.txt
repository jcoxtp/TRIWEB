The installation document for Ultimate Survey is located in the root directory in a file called Install.htm.  

Additional documentation, including the license agreement, is available in the "Documentation" folder.