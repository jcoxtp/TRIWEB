ALTER TABLE [usd_matrixCategories] 

ADD [orderByID] [int] NULL
GO


ALTER TABLE [usd_matrixAnswers] 

ADD [orderByID] [int] NULL
GO